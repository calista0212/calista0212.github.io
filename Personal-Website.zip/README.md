Home:
-Talk a little bit about myself and some facts about me. 
-Having included a picture of me and coded in a contact and portfolio page as well. 

Portfolio:
-I have just a few of my baking goodies, which I should probably add more to.
-For the description I have put them into alterantive text but haven't actually showed them, yet.

Contact:
-I have put contact info of my own.
As well as hyperlinks on my social media and cookie image to take you back to the portfolio. 


Challenges: Making the descriptions for the images on the portfolio show, obviously lol.
